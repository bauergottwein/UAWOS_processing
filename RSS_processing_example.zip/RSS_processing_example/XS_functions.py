# -*- coding: utf-8 -*-
"""
Created on Sat Sep  2 20:08:42 2023

@author: pbau
"""
import numpy as np
from osgeo import gdal
from scipy import interpolate
from scipy.optimize import curve_fit,minimize
from datetime import datetime, timedelta
import pandas as pd
import geopandas as gpd
import shapely
from shapely.geometry import Point
import segyio
from sklearn.linear_model import LinearRegression
from scipy.stats import norm
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt
import fiona
from scipy.interpolate import make_interp_spline
from scipy.interpolate import UnivariateSpline
from scipy.integrate import simpson
from scipy.ndimage import gaussian_filter
import os

from fiona.drvsupport import supported_drivers
supported_drivers['LIBKML'] = 'rw'


def hubdist(points_in,hubs,tol,**kwargs): # matches data points to a reference line
    Easting = 'Easting'
    Northing = 'Northing'
    if 'Easting' in kwargs:
        Easting = kwargs.get('Easting', None)
    if 'Northing' in kwargs:
        Northing = kwargs.get('Northing', None)
    points = points_in.copy(deep=True)
    nA = np.array((points_in[Easting],points_in[Northing])).transpose()
    nB = np.array((hubs['Easting'],hubs['Northing'])).transpose()
    btree = cKDTree(nB)
    dist, idx = btree.query(nA, k=1)
    points['Hubs'] = hubs['Distance'][idx].values
    points['Distance_Hubs'] = dist
    points = points[points['Distance_Hubs']<=tol]
    return points

def xyfromdist(dist, lp_x, lp_y, lp_d, rp_x, rp_y, rp_d): # computes x and y coordinates from distance along a reference line
    x = lp_x +  (rp_x - lp_x) / (rp_d - lp_d) * (dist - lp_d)
    y = lp_y +  (rp_y - lp_y) / (rp_d - lp_d) * (dist - lp_d)
    return x,y

def xy_reg_fromdist(dist, d, x, y): # computes x and y coordinates from distance along a reference line, using regression through points
    regx = LinearRegression().fit(d, x)
    regy = LinearRegression().fit(d, y)
    xout = regx.predict(dist)
    yout = regy.predict(dist)
    return xout,yout
    
def geoidinterp(x,y,n_geoid): # interpolates the geoid value to points, based on a geoid raster input
    geoid = gdal.Open(n_geoid)
    img = geoid.GetRasterBand(1)
    raster = img.ReadAsArray()
    width = geoid.RasterXSize
    height = geoid.RasterYSize
    gt = geoid.GetGeoTransform()
    minx = gt[0]
    miny = gt[3] + width*gt[4] + height*gt[5] 
    maxx = gt[0] + width*gt[1] + height*gt[2]
    maxy = gt[3]
    xg = np.linspace(minx + gt[1]/2,maxx-gt[1]/2,width)
    yg = np.linspace(maxy + gt[5]/2,miny-gt[5]/2,height)
    interp = interpolate.RegularGridInterpolator((-yg, xg), raster,method='linear')
    Geoid = interp(np.array([-np.array(y),x]).transpose())
    return Geoid

def rinterp(x,y,n_raster,nd_value): # interpolates any raster value to points, based on a raster input
    raster = gdal.Open(n_raster)
    img = raster.GetRasterBand(1)
    rasterv = img.ReadAsArray()
    rasterv[np.where(rasterv==nd_value)]=np.nan
    width = raster.RasterXSize
    height = raster.RasterYSize
    gt = raster.GetGeoTransform()
    minx = gt[0]
    miny = gt[3] + width*gt[4] + height*gt[5] 
    maxx = gt[0] + width*gt[1] + height*gt[2]
    maxy = gt[3]
    xg = np.linspace(minx + gt[1]/2,maxx-gt[1]/2,width)
    yg = np.linspace(maxy + gt[5]/2,miny-gt[5]/2,height)
    interp = interpolate.RegularGridInterpolator((-yg, xg), rasterv,method='linear')
    rasterint = interp(np.array([-np.array(y),x]).transpose())
    return rasterint

def skyhubtime(df,datename,timename): #turns time from skyhub into datetime objects
    tt=df[datename] + df[timename]
    t=[]
    for i in tt:
        t.append(np.datetime64(datetime.strptime(i, '%Y/%m/%d%H:%M:%S.%f')))
    return np.array(t)

def posinterp(df,dfpos,datename,timename,latname,lonname,altname,anglesyn): #interpolates accurate positions by matching the time stamp in a position log and a ppk file when time is given as date and time columns
    UTC_GPST_offset = 18*1E6 # in microseconds
    df=df.copy(deep = True)
    tpos = skyhubtime(dfpos,datename,timename)
    tsens = skyhubtime(df,'Date','Time')
    latpos = dfpos[latname]
    tpos = tpos.astype('float')
    if timename == 'GPST':
        tpos = tpos-UTC_GPST_offset
    latint = np.interp(tsens.astype('float'),tpos,latpos)
    lonpos = dfpos[lonname]
    lonint = np.interp(tsens.astype('float'),tpos,lonpos)
    altpos = dfpos[altname]
    altint = np.interp(tsens.astype('float'),tpos,altpos)
    if anglesyn:
        pitchpos = dfpos['Pitch']
        pitchint = np.interp(tsens.astype('float'),tpos,pitchpos)
        rollpos = dfpos['Roll']
        rollint = np.interp(tsens.astype('float'),tpos,rollpos)
        df['Pitch interpolated'] = pitchint
        df['Roll interpolated'] = rollint
    df['Latitude interpolated'] = latint
    df['Longitude interpolated'] = lonint
    df['Altitude interpolated'] = altint
    df = df[np.logical_and(tsens.astype('float')>np.min(tpos),tsens.astype('float')<np.max(tpos))]
    return df

def posinterp_tonly(df,dfpos,datename,timename,latname,lonname,altname,anglesyn): #interpolates accurate positions by matching the time stamp in a position log and a ppk file, when time is given in one single column
    UTC_GPST_offset = 18*1E6 # in microseconds
    df=df.copy(deep = True)
    tpos = skyhubtime(dfpos,datename,timename)
    tsens = df['UTC']
    latpos = dfpos[latname]
    tpos = tpos.astype('float')
    if timename == 'GPST':
        tpos = tpos-UTC_GPST_offset
    latint = np.interp(tsens.values.astype('float64')/1000,tpos,latpos)
    lonpos = dfpos[lonname]
    lonint = np.interp(tsens.values.astype('float64')/1000,tpos,lonpos)
    altpos = dfpos[altname]
    altint = np.interp(tsens.values.astype('float64')/1000,tpos,altpos)
    if anglesyn:
        pitchpos = dfpos['Pitch']
        pitchint = np.interp(tsens.astype('float'),tpos,pitchpos)
        rollpos = dfpos['Roll']
        rollint = np.interp(tsens.astype('float'),tpos,rollpos)
        df['Pitch interpolated'] = pitchint
        df['Roll interpolated'] = rollint
    df['Latitude interpolated'] = latint
    df['Longitude interpolated'] = lonint
    df['Altitude interpolated'] = altint
    df = df[np.logical_and(tsens.values.astype('float64')/1000>np.min(tpos),tsens.values.astype('float64')/1000<np.max(tpos))]
    return df

def processWSEflight(dfin,dfchain,Latitude,Longitude,Altitude,tol,offset_LX80,offset_NRA24,geoidfile,xyEPSG,zEPSG,rangecal): #processes LX80 output
    dfin=dfin.copy(deep = True)
    dfin = dfin.rename(columns={'LX:Distance': 'LX80 slant range', 'Altitude AGL': 'NRA24 slant range'})
    dfin = dfin[dfin['LX80 slant range']<100]
    dfin['geometry'] = dfin.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
    dfin = gpd.GeoDataFrame(dfin, geometry='geometry', crs = 4326)
    dfin = dfin.to_crs(xyEPSG)
    Geoid = geoidinterp(dfin['geometry'].x.values,dfin['geometry'].y.values,geoidfile)
    dfin[zEPSG] = Geoid
    h_geoid = dfin[Altitude] - dfin[zEPSG]
    dfin['Altitude.' + zEPSG + ' (m)'] = h_geoid
    dfin['LX80 slant range'] = rangecal*dfin['LX80 slant range']
    dfin['LX80 nadir range'] = dfin['LX80 slant range']*np.cos(dfin['Roll interpolated']/360*2*np.pi)*np.cos(dfin['Pitch interpolated']/360*2*np.pi)
    dfin['NRA24 nadir range'] = dfin['NRA24 slant range']*np.cos(dfin['Roll interpolated']/360*2*np.pi)*np.cos(dfin['Pitch interpolated']/360*2*np.pi)
    wse_LX80_slant = dfin['Altitude.' + zEPSG + ' (m)'] - dfin['LX80 slant range'] - offset_LX80
    wse_NRA24_slant = dfin['Altitude.' + zEPSG + ' (m)'] - dfin['NRA24 slant range'] - offset_NRA24
    wse_LX80_nadir = dfin['Altitude.' + zEPSG + ' (m)'] - dfin['LX80 nadir range'] - offset_LX80
    wse_NRA24_nadir = dfin['Altitude.' + zEPSG + ' (m)'] - dfin['NRA24 nadir range'] - offset_NRA24
    dfin['WSE LX80 '  + zEPSG + ' slant (m)'] = wse_LX80_slant
    dfin['WSE NRA24 ' + zEPSG + ' slant (m)'] = wse_NRA24_slant
    dfin['WSE LX80 ' + zEPSG + ' nadir (m)'] = wse_LX80_nadir
    dfin['WSE NRA24 ' + zEPSG + ' nadir (m)'] = wse_NRA24_nadir
    dfin['Easting'] = dfin['geometry'].x
    dfin['Northing'] = dfin['geometry'].y
    dfin = dfin.drop(columns = ['Sensor ID','Latitude','Longitude','Heading','LX:Temperature','LX:SNR','LX:SD','LX:Trace'])
    dfin = dfin.drop(columns = ['Latitude interpolated','Longitude interpolated', 'geometry'])
    dfin = hubdist(dfin,dfchain,tol)
    dfin = dfin.rename(columns={'Altitude interpolated': 'Altitude', 'Hubs': 'Chainage (m)', 'Distance_Hubs': 'Distance from centerline (m)'})
    return dfin

def readsegyLX80(filename): #Reads full waveform data from LX80
    skiptraceini = 0 # 
    skiptraceend = 0
    with segyio.open(filename,strict = False,endian = 'little') as f:
        traces = [np.copy(tr) for tr in f.trace[skiptraceini:-(skiptraceend +1)]]
        headers = [head for head in f.header[skiptraceini:-(skiptraceend +1)]]
    ntrace = len(traces)
    print('Number of traces in dataset: ', ntrace)
    trax = np.linspace(1,ntrace,ntrace)
    nsamples = len(traces[0])
    print('Number of samples in each trace: ',nsamples)
    traces = np.transpose(np.array(traces))
    maxrange = 30
    extension = 0.3
    fft_halfsize = 2048
    internal_dist = 0.1732
    rangeax = np.linspace(1,nsamples,nsamples) -1
    rangeax = rangeax * (maxrange + extension)/fft_halfsize - internal_dist
    hdic = []
    tracetime = []
    for i in range(ntrace):
        hnow = dict((a.strip(), int(b.strip()))
                         for a, b in (element.split(':')  
                                      for element in str(headers[i])[2:-1].split(', ')))
        hdic.append(hnow)      
    return rangeax, traces, hdic

def readsegy(filename): #areads full waveform data from WPR/Doppler
    skiptraceini = 0 # 
    skiptraceend = 0
    with segyio.open(filename,strict = False,endian = 'little') as f:
        traces = [np.copy(tr) for tr in f.trace[skiptraceini:-(skiptraceend +1)]]
        headers = [head for head in f.header[skiptraceini:-(skiptraceend +1)]]
        sample_rate = segyio.tools.dt(f) / 1000
    print('Sampling rate: ', sample_rate)
    ntrace = len(traces)
    print('Number of traces in dataset: ', ntrace)
    trax = np.linspace(1,ntrace,ntrace)
    nsamples = len(traces[0])
    print('Number of samples in each trace: ',nsamples)
    traces = np.transpose(np.array(traces))
    hdic = []
    tracetime = []
    for i in range(ntrace):
        hnow = dict((a.strip(), int(b.strip()))
                         for a, b in (element.split(':')  
                                      for element in str(headers[i])[2:-1].split(', ')))
        hdic.append(hnow)      
    return traces, hdic, sample_rate, ntrace, nsamples

def processEchoflight(flight_dict, dfin,dfchain,Latfield,Lonfield,Altfield):
    #df = pd.DataFrame(np.array([dfin['Date'], dfin['Time'], dfin[Lonfield], dfin[Latfield], dfin[Altfield], dfin['ECHO:True Depth'], dfin['ECHO:Trace'], dfin['ECHO:Pitch'], dfin['ECHO:Roll']]).transpose(), columns = ['Date','Time','Longitude','Latitude','Altitude WGS84','Echo Depth','Echo Trace','Pitch','Roll'])
    df = pd.DataFrame(np.array([dfin['Date'], dfin['Time'], dfin[Lonfield], dfin[Latfield], dfin[Altfield], dfin['ALT:Altitude'], dfin['ECHO:True Depth'], dfin['ECHO:Pitch'], dfin['ECHO:Roll']]).transpose(), columns = ['Date','Time','Longitude','Latitude','Altitude WGS84','Altitude TTF','Echo Depth','Pitch','Roll'])
    df.loc[df['Echo Depth']==0,'Echo Depth'] = np.nan
    df['geometry'] = df.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
    df = gpd.GeoDataFrame(df, geometry='geometry', crs = 4326)
    df = df.to_crs(flight_dict ['Aux data']['xyEPSG'])
    df = df.loc[~np.isnan(df['geometry'].x.values)]
    Geoid = geoidinterp(df['geometry'].x.values,df['geometry'].y.values,flight_dict ['Aux data']['geoid'])
    df[flight_dict ['Aux data']['zEPSG']] = Geoid
    h_geoid = df['Altitude WGS84'] - df[flight_dict ['Aux data']['zEPSG']]
    df['Altitude.' + flight_dict ['Aux data']['zEPSG'] + ' (m)'] = h_geoid
    bot = flight_dict['Aux data']['WSE'] - df['Echo Depth']
    df['z.' + flight_dict ['Aux data']['zEPSG'] + ' (m)'] = bot
    df['Easting'] = df['geometry'].x
    df['Northing'] = df['geometry'].y
    df = hubdist(df,dfchain,flight_dict ['flights'][1]['Line tolerance'])
    return df

def processEchoflight_dict(flight_dict):
    cl = gpd.read_file(flight_dict['Aux data']['Filename reference line'])
    cl = cl.to_crs(crs=flight_dict ['Aux data']['xyEPSG'])
    dfchain = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl[flight_dict ['Aux data']['chainage field']]]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    for flight in flight_dict['flights']:
        echo_data = pd.read_csv(flight_dict['flights'][flight]['posfile'])
        Latfield = 'Latitude RTK'
        Lonfield = 'Longitude RTK'
        Altfield = 'Altitude RTK'
        if flight_dict['flights'][flight]['RTK status'] == 'OFF':
            echo_ppk = pd.read_csv(flight_dict['flights'][flight]['PPK file'],skiprows = 9,delimiter=r"\s+")
            echo_data = posinterp(echo_data,echo_ppk,'%','UTC','latitude(deg)','longitude(deg)', 'height(m)',False)
            Latfield = 'Latitude interpolated'
            Lonfield = 'Longitude interpolated'
            Altfield = 'Altitude interpolated'
        echo_data = processEchoflight(flight_dict, echo_data,dfchain,Latfield,Lonfield,Altfield)
        bathydata = echo_data[['Date','Time','Easting','Northing','Hubs', 'z.' + flight_dict ['Aux data']['zEPSG'] + ' (m)','Pitch','Roll']].copy(deep = True)
        bathydata = bathydata.rename(columns={'Hubs': 'Cross section coordinate (m)'})
        bathydata = bathydata[~bathydata['z.' + flight_dict ['Aux data']['zEPSG'] + ' (m)'].isnull()]
        bathydata = bathydata[np.abs(bathydata['Pitch'])<flight_dict['flights'][flight]['Pitch tolerance']]
        bathydata = bathydata[np.abs(bathydata['Roll'])<flight_dict['flights'][flight]['Roll tolerance']]
        bathydata = bathydata.drop('Pitch', axis=1)
        bathydata = bathydata.drop('Roll', axis=1)
        flight_dict['flights'][flight]['Bathymetry points from real time output'] = bathydata
#         if flight_dict['flights'][flight]['segyfile'] != 'na':
#             data,headers,sample_rate, ntrace, nsamples = readsegy(flight_dict['flights'][flight]['segyfile'])
#             ttorange = sample_rate*1E-3 * flight_dict['Aux data']['Speed of sound in water'] / 2
#             thresh = flight_dict['flights'][flight]['Return threshold']
#             traceindex = np.empty(data.shape[1])
#             distindex = np.empty(data.shape[1])
#             elindex = np.empty(data.shape[1])
#             for i in range(data.shape[1]):
#                 traceindex[i] = i
#                 distindex[i] = echo_data.loc[echo_data['Echo Trace'] ==  i]['Hubs'].values
#                 elindex[i] = echo_data.loc[echo_data['Echo Trace'] ==  i]['Altitude SWEN17_RH2000'].values
#             XXv,YYv = np.meshgrid(distindex,np.linspace(1,nsamples,nsamples))
#             plt.figure()
#             starttrace = flight_dict['flights'][flight]['Start trace']
#             endtrace = flight_dict['flights'][flight]['End trace']
#             maxrange = flight_dict['flights'][flight]['Max range']
#             XXv = XXv[0:maxrange,starttrace:endtrace]
#             YYv = YYv[0:maxrange,starttrace:endtrace]
#             data = data[0:maxrange,starttrace:endtrace]
#             elindex = elindex[starttrace:endtrace]
#             distindex = distindex[starttrace:endtrace]
#             plt.pcolor(XXv, YYv*ttorange,data,vmin = 0, vmax = flight_dict['flights'][flight]['Return threshold'])
#             plt.xlabel('Chainage, m')
#             plt.ylabel('ECS400S range, m')
#             plt.show()
#             if flight_dict['Aux data']['Manual pick']:
#                 points_pick = plt.ginput(-1,timeout = -1)
#                 points_pick = np.array(points_pick)
#                 points_pick[:,1]=elindex.mean()-tether_length-points_pick[:,1]
#                 flight_dict['flights'][flight]['Picked points'] = points_pick
# #            input("Press Enter to continue...")
#             elevations = np.empty(data.shape[1])
#             easting = np.empty(data.shape[1])
#             northing = np.empty(data.shape[1])
#             for i in range(data.shape[1]):
#                 easting[i] = dfchain.loc[dfchain['Distance'] == distindex[i], 'Easting'].iloc[0]
#                 northing[i] = dfchain.loc[dfchain['Distance'] == distindex[i], 'Northing'].iloc[0]
#                 if np.where(data[:,i]>thresh)[0].size==0:
#                     elevations[i] = np.nan
#                 else:
#                     elevations[i] = elindex[i] - tether_length - YYv[np.where(data[:,i]>thresh)[0][0],i]*ttorange
#             bathydata = pd.DataFrame(np.transpose(np.array([easting, northing, distindex, elevations])),columns =['Easting', 'Northing','Distance along reference line (m)','Bottom elevation SWEN17_RH2000'])
#             bathydata = bathydata[~bathydata['Bottom elevation SWEN17_RH2000'].isnull()]
#             flight_dict['flights'][flight]['Bathymetry points from full waveform output'] = bathydata  
    return flight_dict


def processWPRflight(flight_dict,dfin,dfchain,latname,lonname,altname):
    df = pd.DataFrame(np.array([dfin['Date'], dfin['Time'], dfin[lonname], dfin[latname], dfin[altname], dfin['ALT:Altitude'], dfin['zGPR:Trace']]).transpose(), columns = ['Date','Time','Longitude','Latitude','Altitude WGS84','Altitude TTF','GPR Trace']) 
    df['geometry'] = df.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
    df = gpd.GeoDataFrame(df, geometry='geometry', crs = 4326)
    df = df.to_crs(flight_dict ['Aux data']['xyEPSG'])
    Geoid = geoidinterp(df['geometry'].x.values,df['geometry'].y.values,flight_dict['Aux data']['geoid'])
    df[flight_dict['Aux data']['zEPSG']] = Geoid
    h_geoid = df['Altitude WGS84'] - df[flight_dict['Aux data']['zEPSG']]
    df['Altitude.' + flight_dict['Aux data']['zEPSG']] = h_geoid
    df['Easting'] = df['geometry'].x
    df['Northing'] = df['geometry'].y
    df = hubdist(df,dfchain,flight_dict['Aux data']['refline tol'])
    return df

def processWPRflight_dict(flight_dict): 
    fsize = 18
    geoidfile = flight_dict['Aux data']['geoid']
    xyEPSG = flight_dict  ['Aux data']['xyEPSG']
    zEPSG = flight_dict  ['Aux data']['zEPSG']
    cl = gpd.read_file(flight_dict['Aux data']['Filename reference line'])
    cl = cl.to_crs(crs=flight_dict ['Aux data']['xyEPSG'])
    dfref = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl[flight_dict ['Aux data']['chainage field']]]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    eps = 81 #relative permittivity of water
    vwat = 3E8/eps**0.5
    for flight in flight_dict['flights']:
        n_posfile = flight_dict ['flights'][flight]['posf_name']
        n_segyfile = flight_dict ['flights'][flight]['segy_name']
        sections = pd.read_excel(flight_dict ['flights'][flight]['sections'],index_col = 'Section')
        pos_data = pd.read_csv(n_posfile)
        lat_name = 'Latitude RTK'
        lon_name = 'Longitude RTK'
        alt_name = 'Altitude RTK'
        txt=flight_dict['flights'][flight]['segy_name']
        sgy_name=txt.split('\\')[-1]
        if not flight_dict ['flights'][flight]['RTK on']:
            n_ppkfile = flight_dict ['flights'][flight]['ppk_name']
            ppk_data = pd.read_csv(n_ppkfile,skiprows = 9,delimiter=r"\s+")
            pos_data = posinterp(pos_data,ppk_data,'%','UTC','latitude(deg)','longitude(deg)', 'height(m)', False)
            lat_name = 'Latitude interpolated'
            lon_name = 'Longitude interpolated'
            alt_name = 'Altitude interpolated'
        pos_data = processWPRflight(flight_dict,pos_data,dfref,lat_name, lon_name, alt_name)
        data,headers, sample_rate, ntrace, nsamples = readsegy(n_segyfile)
        ttorange = sample_rate*1E-9*vwat/2 #sampling rate in ns
        flight_dict ['flights'][flight]['manual bathymetry points']=dict()
        flight_dict ['flights'][flight]['automatic bathymetry points']=dict()
        for s in sections.index:
            starti = pos_data.loc[pos_data['GPR Trace'] == sections['Start Trace'][s]].index -1
            endi = pos_data.loc[pos_data['GPR Trace'] == sections['End Trace'][s]].index +1
            indeces = range(starti[0],endi[0])
            spos_data = pos_data.iloc[np.array(indeces)]
            stime = skyhubtime(spos_data,'Date','Time').astype('float').astype('datetime64[us]')
            feast = interpolate.interp1d(spos_data['Hubs'],spos_data['Easting'])
            fnorth = interpolate.interp1d(spos_data['Hubs'],spos_data['Northing'])
            falt = interpolate.interp1d(spos_data['Hubs'],spos_data['Altitude.' + flight_dict['Aux data']['zEPSG']])
            fts = interpolate.interp1d(spos_data['Hubs'],stime)
            subdata = data[:,sections['Start Trace'][s]:sections['End Trace'][s]+1]
            ntrace = sections['End Trace'][s] - sections['Start Trace'][s] + 1
            #Background removal
            mdata = subdata.mean(1)
            mmdata = np.tile(mdata,(subdata.shape[1],1)).transpose()
            ndata = subdata-mmdata
            #surface identificatation
            otrace = np.abs(ndata).mean(1)
            surf = np.where(otrace==max(otrace))[0][0]*ttorange
            # Linear gain
            traceindex = np.empty(subdata.shape[1])
            distindex = np.empty(subdata.shape[1])
            for i in range(subdata.shape[1]):
                traceindex[i] = sections['Start Trace'][s] + i
                distindex[i] = pos_data.loc[pos_data['GPR Trace'] == sections['Start Trace'][s]+ i]['Hubs'].values
            rangeax = np.linspace(1,nsamples,nsamples)*ttorange
            gain = ((rangeax-flight_dict ['flights'][flight]['gain lt'])/(flight_dict ['flights'][flight]['gain ut']-flight_dict ['flights'][flight]['gain lt']))**flight_dict ['flights'][flight]['gain power']
            gain[rangeax<flight_dict ['flights'][flight]['gain lt']]=0
            gain[rangeax>flight_dict ['flights'][flight]['gain ut']]=1
            mgain = np.tile(gain,(subdata.shape[1],1)).transpose()
            gndata = ndata*mgain
            
            XXv, YYv = np.meshgrid(distindex, rangeax)
            #%% Figure 1
            plt.figure()
            plt.pcolor(XXv, YYv, gndata, vmin=np.percentile(gndata, 0.05), vmax=np.percentile(gndata, 99.9))
            idx = np.argmax(gndata, axis=0)
            plt.plot(distindex, idx*ttorange, 'r.')
            plt.xlabel('Distance along cross section, m', fontsize=fsize)
            plt.ylabel('GPR range, m', fontsize=fsize)
            plt.title(flight_dict['Aux data']['XSid'] + ': ' + sgy_name + '_' + str(s), fontsize=fsize)
            plt.tick_params(labelsize=fsize)
            # %% Pick some points for constructing a filter, which was used to filter out signals with shorter time (values =0)
            print('Please pick a rough lower bound on the bathymetry range by right-clicking your mouse, and clicking the middle for the ending:')
            # Figure 2
            plt.figure()
            plt.pcolor(gndata, vmin=np.percentile(gndata, 0.05),vmax=np.percentile(gndata, 99.9))
            plt.plot(idx, 'r.')
            points_prof = plt.ginput(-1, timeout=-1, show_clicks=True,mouse_add=3, mouse_pop=1, mouse_stop=2)
            points_prof = np.array(points_prof)
            points_prof[0, 0] = 0
            points_prof[-1, 0] = gndata.shape[1]
            f = interpolate.interp1d(points_prof[:, 0], points_prof[:, 1])
            trax = np.linspace(0, gndata.shape[1]-1, gndata.shape[1])
            rax = np.linspace(0, gndata.shape[0]-1, gndata.shape[0])
            thresh_range = f(trax)
            plt.plot(trax, thresh_range, 'w.')
            plt.xlabel('Traces', fontsize=fsize)
            plt.ylabel('GPR range, time', fontsize=fsize)
            plt.title(flight_dict['Aux data']['XSid'] +': ' + sgy_name+'_' + str(s), fontsize=fsize)
            plt.tick_params(labelsize=fsize)
            tthresh_range = np.tile(thresh_range, (subdata.shape[0], 1))
            thrx, thry = np.meshgrid(trax, rax)
            tgndata = gndata*(thry > tthresh_range)
# %%         To construct a Gaussian lowpass filter
            filtedData = gaussian_filter(tgndata, sigma=2)
            tgndata=filtedData
#%%         Figure 3 (after filtering by a lowpass filter)
            plt.figure()
            plt.pcolor( tgndata, vmin=np.percentile(tgndata, 0.1),vmax=np.percentile(tgndata, 99.9))
            plt.xlabel('Traces', fontsize=fsize)
            plt.ylabel('GPR range, time', fontsize=fsize)
            plt.title(flight_dict['Aux data']['XSid'] +': ' + sgy_name+'_' + str(s), fontsize=fsize)
            plt.tick_params(labelsize=fsize)
            # Automatic picking max value of each trace
            gndata = filtedData
            idx = np.argmax(gndata, axis=0)
            m = len(gndata[1])
            points_prof = np.zeros((m, 2))
            points_prof = np.array(points_prof)
            num_1 = 0
            for ii in range(0, m):
                points_prof[ii, 0] = num_1
                points_prof[ii, 1] = idx[ii]
                num_1 = num_1+1
            points_prof[:, 1] = np.around(points_prof[:, 1], 4)
            plt.plot(points_prof[:, 0], points_prof[:, 1], 'r.')
            # manual updating by picking
            print('Please manual updating by right-clicking your mouse, and clicking the middle for the ending:')
            points_surf = plt.ginput(-1, timeout=-1, show_clicks=True,mouse_add=3, mouse_pop=1, mouse_stop=2)
            points_manu = np.array(points_surf)
            plt.plot(points_manu[:, 0], points_manu[:, 1], 'w*')
            for idx in range(points_manu.shape[0]):
                new_idx = int(np.around(points_manu[idx, 0]))
                points_prof[new_idx, 1] = points_manu[idx, 1]
# %%        Figure 4 for showing updated results
            plt.figure() 
            plt.pcolor(XXv, YYv, gndata, vmin=np.percentile(gndata, 0.05), vmax=np.percentile(gndata, 99.9))
            plt.plot(distindex, points_prof[:, 1]*ttorange, 'r.')
            plt.xlabel('Distance along cross section, m', fontsize=fsize)
            plt.ylabel('GPR range, m', fontsize=fsize)
            plt.title(flight_dict['Aux data']['XSid'] +': ' + sgy_name + '_' + str(s), fontsize=fsize)
            plt.tick_params(labelsize=fsize)
# %%        Caculating the bathymetry
            points_prof[:, 1] = points_prof[:, 1]*ttorange-surf
            wse = flight_dict['Aux data']['WSE']
            points_prof[:, 1] = wse - points_prof[:, 1]
            dfbathyauto = pd.DataFrame({'Cross section coordinate (m)': distindex, 'z.' + zEPSG + ' (m)': points_prof[:, 1]})
            dfbathyauto['x.' + xyEPSG +' (m)'] = feast(dfbathyauto['Cross section coordinate (m)'])
            dfbathyauto['y.' + xyEPSG +' (m)'] = fnorth(dfbathyauto['Cross section coordinate (m)'])
            dfbathyauto['Altitude.' + zEPSG +' (m)'] = falt(dfbathyauto['Cross section coordinate (m)'])
            dfbathyauto['Time stamp (UTC)'] = fts(dfbathyauto['Cross section coordinate (m)']).astype('float').astype('datetime64[us]')
            flight_dict['flights'][flight]['automatic bathymetry points'][s] = dfbathyauto
    return flight_dict 
          
    

def processRSS300flight(flight_dict,dfin,dfchain,latname,lonname,altname):
    df = pd.DataFrame(np.array([dfin['Date'], dfin['Time'], dfin[lonname], dfin[latname], dfin[altname], dfin['RSS:Velocity raw'], dfin['RSS:Velocity filtered'], dfin['RSS:Tilt'], dfin['RSS:Trace'], dfin['RSS:Direction']]).transpose(), columns = ['Date','Time','Longitude','Latitude','Altitude WGS84','Velocity raw', 'Velocity filtered', 'Tilt', 'Trace', 'Direction']) 
    df['geometry'] = df.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
    df = gpd.GeoDataFrame(df, geometry='geometry', crs = 4326)
    df = df.to_crs(flight_dict ['Aux data']['xyEPSG'])
    Geoid = geoidinterp(df['geometry'].x.values,df['geometry'].y.values,flight_dict['Aux data']['geoid'])
    df[flight_dict['Aux data']['zEPSG']] = Geoid
    h_geoid = df['Altitude WGS84'] - df[flight_dict['Aux data']['zEPSG']]
    df['Altitude.' + flight_dict['Aux data']['zEPSG'] + ' (m)'] = h_geoid
    df['Easting'] = df['geometry'].x
    df['Northing'] = df['geometry'].y
    df = hubdist(df,dfchain,flight_dict['Aux data']['refline tol'])
    return df

def processRSS300flight_dict(flight_dict):
    geoidfile = flight_dict['Aux data']['geoid']
    cl = gpd.read_file(flight_dict['Aux data']['Filename reference line'])
    cl = cl.to_crs(crs=flight_dict['Aux data']['xyEPSG'])
    dfref = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl[flight_dict['Aux data']['chainage field']]]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    lat_name = 'Latitude'
    lon_name = 'Longitude'
    alt_name = 'Altitude RTK'
    for flight in flight_dict['flights']:
        flight_dict['flights'][flight]['pos'] = pd.read_csv(flight_dict['flights'][flight]['posf_name'],skiprows = 9,delimiter=r"\s+")
        flight_dict['flights'][flight]['RSS']  = pd.read_csv(flight_dict['flights'][flight]['RSSf_name'])
        flight_dict['flights'][flight]['RSS'] = processRSS300flight(flight_dict, flight_dict['flights'][flight]['RSS'],dfref,lat_name,lon_name,alt_name)
        flight_dict['flights'][flight]['waypoints'] = pd.read_excel(flight_dict['flights'][flight]['Waypoint file name'],index_col = 0)
        # plt.plot(flight_dict['flights'][flight]['RSS']['Hubs'],flight_dict['flights'][flight]['RSS']['Velocity raw']*100,'b.', label='RSS300')
        # plt.show()
        cfreq = 24E9 #Hz, center frequency of the Doppler radar
        spol = 3E8 # Speed of light in air, m/s
        wlen = spol/cfreq # radar wavelength, m
        print('Wavelength of Doppler radar in m:', wlen)
        dshift = 2/wlen # 1/m, i.e. Hz/(m/s),i.e. Doppler shift per velocity
        print('Doppler shift per unit speed in 1/m or Hz/(m/s): ', dshift)
        vres = 7.3921 # mm/s velocity resolution of the Doppler radar, according to Geolux
        specres = specres = vres/1000*dshift #spectral resolution of the Doppler radar
        print('Spectral resolution of Doppler spectrum in Hz: ', specres)
        vaxis = np.concatenate((np.linspace(1,2048,2048)*vres,np.linspace(-2048,-1,2048)*vres))
        print('Velocity axis of the radar plot in mm/s: ', vaxis)
        faxis = np.concatenate((np.linspace(1,2048,2048)*specres,np.linspace(-2048,-1,2048)*specres))
        print('Frequency axis of the radar plot in Hz: ',faxis)
        angle = 45 # 
        n_segyfile = flight_dict['flights'][flight]['segy_name']
        data,headers, sample_rate, ntrace, nsamples = readsegy(n_segyfile)
        trax = np.linspace(1,ntrace,ntrace)
        flight_dict['flights'][flight]['fwf_data'] =np.concatenate((data[2048:,:],data[0:2048,:]))
        flight_dict['flights'][flight]['vaxis_sort'] = np.concatenate((np.linspace(-2048,-1,2048)*vres, np.linspace(1,2048,2048)*vres))/10/ np.cos(angle/360*2*np.pi)
        #Plot in velocity
        # XXv,YYv = np.meshgrid(trax,flight_dict['flights'][flight]['vaxis_sort'])
        # plt.figure()
        # plt.pcolor(XXv,YYv,flight_dict['flights'][flight]['fwf_data'],vmin = 0, vmax = 800)
        # plt.ylim(-2,2)
        # plt.xlabel('traces')
        # plt.ylabel('Velocity, m/s')
        # plt.show()
        flight_dict['flights'][flight]['waypoints']["Cross section coordinate (m)"] = ""
        flight_dict['flights'][flight]['waypoints']["RT Velocity"] = ""
        flight_dict['flights'][flight]['waypoints']["Time stamp"] = ""
        flight_dict['flights'][flight]['waypoints']["Easting"] = ""
        flight_dict['flights'][flight]['waypoints']["Northing"] = ""
        flight_dict['flights'][flight]['waypoints']['Altitude.' + flight_dict['Aux data']['zEPSG'] + ' (m)'] = ""
        flight_dict['flights'][flight]['waypoints']['popt'] = ""
        flight_dict['flights'][flight]['waypoints']['pcov'] = ""
        flight_dict['flights'][flight]['waypoints']['fit_vax'] = ""
        flight_dict['flights'][flight]['waypoints']['fit_data'] = ""
        flight_dict['flights'][flight]['waypoints']['FW Velocity'] = np.nan
        flight_dict['flights'][flight]['popt'] = dict()
        flight_dict['flights'][flight]['pcov'] = dict()
        flight_dict['flights'][flight]['fit_vax'] = dict()
        flight_dict['flights'][flight]['fit_data'] = dict()
        for w in flight_dict['flights'][flight]['waypoints'].index:
            subflight = flight_dict['flights'][flight]['RSS'][np.logical_and(flight_dict['flights'][flight]['RSS']['Trace'] > flight_dict['flights'][flight]['waypoints']['Start Trace'][w], flight_dict['flights'][flight]['RSS']['Trace'] < flight_dict['flights'][flight]['waypoints']['End Trace'][w])]
            subdata = flight_dict['flights'][flight]['fwf_data'][: , flight_dict['flights'][flight]['waypoints']['Start Trace'][w] : flight_dict['flights'][flight]['waypoints']['End Trace'][w] + 1]
            subdata_m = subdata.mean(1)
            vax = flight_dict['flights'][flight]['vaxis_sort']
            vlower = flight_dict['flights'][flight]['waypoints']['v lower'][w]
            vupper = flight_dict['flights'][flight]['waypoints']['v upper'][w]
            ind = np.logical_and(vax >vlower,vax <vupper)
            vax = vax[ind]
            subdata_m = subdata_m[ind]
            vmask = flight_dict['flights'][flight]['waypoints']['v mask'][w]
            ind = np.logical_or(vax <-vmask,vax >vmask)
            vax = vax[ind]
            subdata_m = subdata_m[ind]
            plt.figure()
            plt.pcolor(np.linspace(1,subdata.shape[1],subdata.shape[1]),flight_dict['flights'][flight]['vaxis_sort'],subdata,vmin = 0, vmax = 500)
            plt.ylim([-200, 200])
            plt.xlabel('Traces')
            plt.ylabel('Flow velocity, cm/s')
            flight_dict['flights'][flight]['waypoints'].loc[w,'Cross section coordinate (m)'] = subflight['Hubs'].values.mean()
            flight_dict['flights'][flight]['waypoints'].loc[w,'Easting'] = subflight['Easting'].values.mean()
            flight_dict['flights'][flight]['waypoints'].loc[w,'Northing'] = subflight['Northing'].values.mean()
            flight_dict['flights'][flight]['waypoints'].loc[w,'Altitude.' + flight_dict['Aux data']['zEPSG'] + ' (m)'] = subflight['Altitude.' + flight_dict['Aux data']['zEPSG'] + ' (m)'].values.mean()
            flight_dict['flights'][flight]['waypoints'].loc[w,'RT Velocity'] = subflight['Velocity raw'].values.mean()*100
            flight_dict['flights'][flight]['waypoints'].loc[w,'Time stamp'] = skyhubtime(subflight,'Date','Time').astype('float').mean().astype('datetime64[us]')
            try:
                if  flight_dict['flights'][flight]['waypoints']['Fitting Model'][w] == 'Single Peak':
                    p0 = [flight_dict['flights'][flight]['waypoints']['m1'][w],flight_dict['flights'][flight]['waypoints']['s1'][w],flight_dict['flights'][flight]['waypoints']['f1'][w]]
                    popt,pcov = curve_fit(peakmodel1, vax, subdata_m, p0=p0)#,bounds=flight_dict ['Aux data']['pm2 bounds'])
                elif flight_dict['flights'][flight]['waypoints']['Fitting Model'][w]  == 'Double Peak':
                    p0 = [flight_dict['flights'][flight]['waypoints']['m1'][w],flight_dict['flights'][flight]['waypoints']['m2'][w],flight_dict['flights'][flight]['waypoints']['s1'][w],flight_dict['flights'][flight]['waypoints']['s2'][w],flight_dict['flights'][flight]['waypoints']['f1'][w],flight_dict['flights'][flight]['waypoints']['f2'][w]]
                    popt,pcov = curve_fit(peakmodel2, vax, subdata_m, p0=p0)
            except RuntimeError:
                print('an error occured in the fitting')
                vpick = np.nan
                plt.plot(vax,subdata_m,'k.')
                print('Flight ' + str(flight) + ' Waypoint ' + str(w) +  ' could not be fitted')
                plt.title ('Flight ' + str(flight) + ' Waypoint ' + str(w))
                plt.show()
                popt = np.nan
                pcov = np.nan
            else:
                if  flight_dict['flights'][flight]['waypoints']['Fitting Model'][w] == 'Single Peak':
                    p0 = [flight_dict['flights'][flight]['waypoints']['m1'][w],flight_dict['flights'][flight]['waypoints']['s1'][w],flight_dict['flights'][flight]['waypoints']['f1'][w]]
                    popt,pcov = curve_fit(peakmodel1, vax, subdata_m, p0=p0)#,bounds=flight_dict ['Aux data']['pm2 bounds'])
                    fdata = peakmodel1(vax,popt[0],popt[1],popt[2])
                    flight_dict['flights'][flight]['waypoints'].loc[w,'FW Velocity'] = popt[0]
                elif flight_dict['flights'][flight]['waypoints']['Fitting Model'][w]  == 'Double Peak':
                    p0 = [flight_dict['flights'][flight]['waypoints']['m1'][w],flight_dict['flights'][flight]['waypoints']['m2'][w],flight_dict['flights'][flight]['waypoints']['s1'][w],flight_dict['flights'][flight]['waypoints']['s2'][w],flight_dict['flights'][flight]['waypoints']['f1'][w],flight_dict['flights'][flight]['waypoints']['f2'][w]]
                    popt,pcov = curve_fit(peakmodel2, vax, subdata_m, p0=p0)
                    fdata = peakmodel2(vax,popt[0],popt[1],popt[2],popt[3],popt[4],popt[5])
                    flight_dict['flights'][flight]['waypoints'].loc[w,'FW Velocity'] = popt[0]
                plt.figure()
                plt.plot(vax,subdata_m,'k.')
                plt.plot(vax,fdata,'r-')
                plt.xlim(vlower,vupper)
                plt.xlabel('Velocity, cm/s')
                plt.ylabel('Return power')
                plt.plot([popt[0],popt[0]],plt.gca().get_ylim())
                if  flight_dict['flights'][flight]['waypoints']['Fitting Model'][w] == 'Double peak':
                    plt.plot([popt[1],popt[1]],plt.gca().get_ylim())
                plt.show()
                phi = sum((fdata-subdata_m)**2/len(fdata))**0.5
                print(phi)
            flight_dict['flights'][flight]['popt'][w]= popt
            flight_dict['flights'][flight]['pcov'][w]= pcov
            flight_dict['flights'][flight]['fit_vax'][w] = vax
            flight_dict['flights'][flight]['fit_data'][w] = subdata_m
            
    return flight_dict

def RSS_L3_generation(flight_dict):

    for flight in flight_dict['flights']:
        XS_L3 = flight_dict['flights'][flight]['waypoints']
        XS_L3=XS_L3.drop(columns=['Start Trace', 'End Trace','m1','m2','s1','s2','f1','f2','Flight Altitude'])
        XS_L3 = XS_L3.rename(columns={
            'RT Velocity': 'Velocity raw cm/s', 
            "FW Velocity": "Velocity full waveform data cm/s",
            })
        XS_L3 = XS_L3[['Time stamp','Easting', 'Northing', 'Altitude.' + flight_dict['Aux data']['zEPSG'] + ' (m)', 'Cross section coordinate (m)', 'Velocity raw cm/s',"Velocity full waveform data cm/s" ]]
        XS_L3 = XS_L3.rename(columns={
            'Time stamp': 'Time stamp (UTC)',
            'Easting': "x."+flight_dict['Aux data']['xyEPSG'] + ' (m)',
            'Northing': "y." + flight_dict['Aux data']['xyEPSG'] + ' (m)'
            })
        XS_L3.to_csv(flight_dict ['flights'][flight]['L3 output'] )
        XS_L2=XS_L3.drop(columns=[ 'Cross section coordinate (m)'])
        XS_L2.to_csv(flight_dict ['flights'][flight]['L2 output'])

def Zond_L3_generation(flight_dict):
    xyEPSG = flight_dict  ['Aux data']['xyEPSG']
    zEPSG = flight_dict  ['Aux data']['zEPSG']
    XS_L3_auto = flight_dict['flights'][0]['automatic bathymetry points'][1].head(0)
    XS_L3_auto['Frequency (MHz)'] = None
    XS_L3_auto['Antenna direction'] = None
    XS_L3_auto['WSE.' + zEPSG + ' (m)'] = None
    for flight in flight_dict['flights']:
        for s in flight_dict['flights'][flight]['automatic bathymetry points']:
            df = flight_dict['flights'][flight]['automatic bathymetry points'][s]
            if 'cfreq' not in flight_dict ['flights'][flight].keys():
                df['Frequency (MHz)'] = 80
            else:
                df['Frequency (MHz)'] = flight_dict['flights'][flight] ['cfreq']
            if 'dir' not in flight_dict ['flights'][flight].keys():
                df['Antenna direction'] = 'perpendicular'
            else:
                df['Antenna direction'] = flight_dict['flights'][flight] ['dir']
            df['WSE.' + zEPSG + ' (m)'] = flight_dict['Aux data']['WSE']
            XS_L3_auto = pd.concat([XS_L3_auto, df], axis=0)
    XS_L3_auto = XS_L3_auto[XS_L3_auto['z.' + zEPSG + ' (m)'].notna()]
    XS_L3_auto.to_csv(flight_dict ['Aux data']['L3 output auto'], index = False)
    XS_L2_auto=XS_L3_auto.drop(columns=['Cross section coordinate (m)'])
    XS_L2_auto.to_csv(flight_dict ['Aux data']['L2 output auto'], index = False )


def ECT400_L3_generation(flight_dict):
    L3data = flight_dict['flights'][1]['Bathymetry points from real time output'][0:0]
    for flight in flight_dict['flights']:
        L3data = pd.concat([L3data, flight_dict['flights'][flight]['Bathymetry points from real time output']])
    L3data = L3data.rename(columns={'Distance along reference line (m)': 'Cross section coordinate (m)', 'Easting': "x."+flight_dict['Aux data']['xyEPSG'] + ' (m)', 'Northing': "y." + flight_dict['Aux data']['xyEPSG'] + ' (m)', 'Bottom elevation SWEN17_RH2000': 'z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'})
    L3data.to_csv(flight_dict['Aux data']['L3_output'],index = False)
    L2data = L3data.drop('Cross section coordinate (m)', axis=1)
    L2data.to_csv(flight_dict['Aux data']['L2_output'],index = False)
    L3data_fwf = flight_dict['flights'][1]['Bathymetry points from real time output'][0:0]
    for flight in flight_dict['flights']:
        if flight_dict ['Aux data']['FWF data']:
            L3data_fwf = L3data_fwf.append(flight_dict['flights'][flight]['Bathymetry points from full waveform output'])
            L3data_fwf = L3data_fwf.rename(columns={'Distance along reference line (m)': 'Cross section coordinate (m)', 'Easting': "x."+flight_dict['Aux data']['xyEPSG'] + ' (m)', 'Northing': "y." + flight_dict['Aux data']['xyEPSG'] + ' (m)', 'Bottom elevation SWEN17_RH2000': 'z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'})
            L3data_fwf.to_csv(flight_dict['Aux data']['L3_output full waveform'],index = False)
            L2data_fwf = L3data_fwf.drop('Cross section coordinate (m)', axis=1)
            L2data_fwf.to_csv(flight_dict['Aux data']['L2_output full waveform'],index = False)    

def peakmodel2(v,mu1,mu2,s1,s2,f1,f2):
    ret_pow = f1*norm.pdf((v-mu1)/s1) + f2*norm.pdf((v-mu2)/s2)
    return ret_pow

def peakmodel1(v,mu1,s1,f1):
    ret_pow = f1*norm.pdf((v-mu1)/s1)
    return ret_pow

def processLX80flight_dict(flight_dict):
    n_chainfile = flight_dict ['Aux data']['chainage file']
    geoidfile = flight_dict ['Aux data']['geoid']
    cl = gpd.read_file(n_chainfile)
    cl = cl.to_crs(crs=flight_dict ['Aux data']['xyEPSG'])
    dfchain = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl[flight_dict ['Aux data']['chainage field']]]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    for flight in flight_dict['flights']:
        flight_pos = pd.read_csv(flight_dict ['flights'][flight]['n_flight_pos'])
        flight_lx80 = pd.read_csv(flight_dict ['flights'][flight]['n_flight_lx80'])
        if flight_dict ['flights'][flight]['RTK on']:
            flight_pos = flight_pos[flight_pos['RTK Status'] =='ON']
            flight_lx80 = posinterp(flight_lx80,flight_pos,'Date','Time','Latitude RTK','Longitude RTK', 'Altitude RTK',True)
            offset_RTK_LX80 = flight_dict ['Aux data']['offset_RTK_LX80']
            offset_RTK_NRA24 = flight_dict ['Aux data']['offset_RTK_NRA24']
            flight_lx80 = processWSEflight(flight_lx80,dfchain,'Latitude interpolated','Longitude interpolated','Altitude interpolated',flight_dict ['flights'][flight]['CL dist threshold'],offset_RTK_LX80,offset_RTK_NRA24,geoidfile, flight_dict ['Aux data']['xyEPSG'], flight_dict ['Aux data']['zEPSG'], flight_dict ['Aux data']['rangecal'])           
        else:
            flight_ppk = pd.read_csv(flight_dict ['flights'][flight]['n_flight_ppk'],skiprows = 9,delimiter=r"\s+")
            flight_pos = posinterp(flight_pos,flight_ppk,'%','UTC','latitude(deg)','longitude(deg)', 'height(m)',False)
            flight_lx80 = posinterp(flight_lx80,flight_pos,'Date','Time','Latitude interpolated','Longitude interpolated', 'Altitude interpolated',True)
            offset_PPK_LX80 = flight_dict ['Aux data']['offset_PPK_LX80']
            offset_PPK_NRA24 = flight_dict ['Aux data']['offset_PPK_NRA24']
            flight_lx80 = processWSEflight(flight_lx80,dfchain,'Latitude interpolated','Longitude interpolated','Altitude interpolated',flight_dict ['flights'][flight]['CL dist threshold'],offset_PPK_LX80,offset_PPK_NRA24,geoidfile, flight_dict ['Aux data']['xyEPSG'], flight_dict ['Aux data']['zEPSG'], flight_dict ['Aux data']['rangecal'])
        flight_dict ['flights'][flight]['Results'] = flight_lx80
    return flight_dict

def LX80_L3_generation(flight_dict):
    for flight in flight_dict['flights']:
        flight_lx80 = flight_dict['flights'][flight]['Results']
        flight_lx80 = flight_lx80.rename(columns={
            'NRA24 slant range': 'NRA24 slant range (m)',
            'LX80 slant range': 'LX80 slant range (m)',
            'Pitch interpolated': 'Pitch interpolated (deg)',
            'Roll interpolated': 'Roll interpolated (deg)',
            'Altitude': 'Altitude.EPSG:4326 (m)',
            'SWEN17_RH2000': 'SWEN17_RH2000.EPSG:4326 (m)',
            'Altitude SWEN17_RH2000': 'Altitude.' + flight_dict ['Aux data']['zEPSG'] + ' (m)',
            'Easting': "x."+flight_dict['Aux data']['xyEPSG'] + ' (m)',
            'Northing': "y." + flight_dict['Aux data']['xyEPSG'] + ' (m)',
            'LX80 nadir range': 'LX80 nadir range (m)',
            'NRA24 nadir range': 'NRA24 nadir range (m)',
            'WSE LX80 SWEN17_RH2000 slant': 'WSE.' + flight_dict['Aux data']['zEPSG'] + '.LX80 slant (m)',
            'WSE NRA24 SWEN17_RH2000 slant': 'WSE.' + flight_dict['Aux data']['zEPSG'] + '.NRA24 slant (m)',
            'WSE LX80 SWEN17_RH2000 nadir': 'WSE.' + flight_dict['Aux data']['zEPSG'] + '.LX80 nadir (m)',
            'WSE NRA24 SWEN17_RH2000 nadir': 'WSE.' + flight_dict['Aux data']['zEPSG'] + '.NRA24 nadir (m)',
            })
        flight_lx80_L2 = flight_lx80.copy(deep = True)
        flight_lx80_L2 = flight_lx80_L2.drop(columns = ['Chainage (m)', 'Distance from centerline (m)'])
        flight_lx80_L2.to_csv(flight_dict['flights'][flight]['L2 output'],index = False)
        flight_lx80 = flight_lx80[flight_lx80['Distance from centerline (m)']<=flight_dict['flights'][flight]['CL dist threshold']]
        flight_lx80.to_csv(flight_dict['flights'][flight]['L3 output'],index = False)
        
def processHydrohex_dict(flight_dict,tol):
    cl = gpd.read_file(flight_dict['Aux data']['Filename reference line'])
    cl = cl.to_crs(crs=3006)
    dfchain = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl['Distance']]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    for flight in flight_dict['flights']:
        df_coord = pd.read_csv(flight_dict ['flights'][flight]['coordfile'],delimiter=';')
        df_coord = df_coord[df_coord['GNSS time as year-month-day hour:min:sec.nano'].notna()]
        GNSS_ts=np.empty(0)
        Sys_ts=np.empty(0)
        for ts in df_coord['GNSS time as year-month-day hour:min:sec.nano']:
            GNSS_ts = np.append(GNSS_ts,Hydrohexts_convert(ts,'nano'))
        for ts in df_coord['system time as year-month-day hour:min:sec.microsecond']:
            Sys_ts = np.append(Sys_ts,Hydrohexts_convert(ts,'micro'))
        df_coord['GNSS_ts'] = GNSS_ts
        df_coord['Sys_ts'] = Sys_ts
        df_coord = df_coord[df_coord['GNSS_ts'].notna()]
        df_sonar = pd.read_csv(flight_dict ['flights'][flight]['sonarfile'],delimiter=';')
        df_sonar = df_sonar[df_sonar['timestamp'].notna()]
        Sys_ts=np.empty(0)
        for ts in df_sonar['timestamp']:
            Sys_ts = np.append(Sys_ts,Hydrohexts_convert(ts,'micro'))
        df_sonar['Sys_ts'] = Sys_ts
        df_sonar['UTC'] = pd.to_datetime(np.interp(df_sonar['Sys_ts'].values.astype('float64'),df_coord['Sys_ts'].values.astype('float64'),df_coord['GNSS_ts'].values.astype('float64')))
        dfpos = pd.read_csv(flight_dict['flights'][flight]['PPK file'],skiprows = 9,delimiter=r"\s+")
        df_sonar = posinterp_tonly(df_sonar,dfpos,'%','UTC','latitude(deg)','longitude(deg)', 'height(m)', False)
        df_sonar = df_sonar.rename(columns={'Latitude interpolated': 'Latitude', 'Longitude interpolated': 'Longitude'})
        df_sonar = df_sonar.drop(columns = {'Altitude interpolated'})
        df_sonar['geometry'] = df_sonar.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
        df_sonar = gpd.GeoDataFrame(df_sonar, geometry='geometry', crs = 4326)
        df_sonar = df_sonar.to_crs(3006)
        df_sonar['Easting'] = df_sonar['geometry'].x
        df_sonar['Northing'] = df_sonar['geometry'].y
        df_sonar = hubdist(df_sonar,dfchain,tol)   
        df_sonar = df_sonar[(df_sonar['Depth_Meters'] > 0)]
        df_sonar = df_sonar[(df_sonar['Depth_Meters'] < 100)]
        df_sonar['Bottom elevation SWEN17_RH2000'] = flight_dict['Aux data']['WSE'] - df_sonar['Depth_Meters']
        flight_dict ['flights'][flight]['results'] = df_sonar
    return flight_dict

def readDeeperChirpfile(fname):
    file = open(fname)
    Lines = file.readlines()
    count = 0
    t = np.empty(0)
    depth = np.empty(0)
    for line in Lines:
        if 'Date' in line:
            date = datetime.strptime(line.split(':')[1], " %d.%m.%Y\n")
        if '$GNGGA' in line:
            tnow = line.split(',')[1]
            hours = float(tnow[0:2])
            mins = float(tnow[2:4])
            secs = float(tnow[4:])
            tnow = timedelta(hours=hours,minutes = mins, seconds=secs)
            t = np.append(t, tnow)
            if '$SDDBT' in Lines[count+1]:
                depthnow = float(Lines[count+1].split(',')[3])
            else:
                depthnow = 0
            depth = np.append(depth,depthnow)
        count = count + 1
    t = t[depth!=0]
    depth = depth[depth!=0]
    t = date + t
    data=np.array([t,depth])
    dfdepth = pd.DataFrame(data.transpose(),columns=['UTC','Depth (m)'])
    return dfdepth

def processDeeperChirp_dict(flight_dict,tol):
    cl = gpd.read_file(flight_dict['Aux data']['Filename reference line'])
    cl = cl.to_crs(crs=3006)
    dfchain = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl['Distance']]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    for flight in flight_dict['flights']:
        dfdepth = readDeeperChirpfile(flight_dict ['flights'][flight]['chirpfile'])
        dfpos = pd.read_csv(flight_dict['flights'][flight]['PPK file'],skiprows = 9,delimiter=r"\s+")
        dfdepth = posinterp_tonly(dfdepth,dfpos,'%','UTC','latitude(deg)','longitude(deg)', 'height(m)', False)
        dfdepth = dfdepth.rename(columns={'Latitude interpolated': 'Latitude', 'Longitude interpolated': 'Longitude'})
        dfdepth = dfdepth.drop(columns = {'Altitude interpolated'})
        dfdepth['geometry'] = dfdepth.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
        dfdepth = gpd.GeoDataFrame(dfdepth, geometry='geometry', crs = 4326)
        dfdepth = dfdepth.to_crs(3006)
        dfdepth['Easting'] = dfdepth['geometry'].x
        dfdepth['Northing'] = dfdepth['geometry'].y
        dfdepth = hubdist(dfdepth,dfchain,tol)
        dfdepth['Bottom elevation SWEN17_RH2000'] = flight_dict['Aux data']['WSE'] - dfdepth['Depth (m)']
        flight_dict ['flights'][flight]['results'] = dfdepth
    return flight_dict

def DeeperChirp_L3_generation(flight_dict):
    flight_chirp = flight_dict['flights'][1]['results'][0:0]
    for flight in flight_dict['flights']:
        flight_chirp = flight_chirp.append(flight_dict['flights'][flight]['results'])
    flight_chirp = flight_chirp[['UTC','Easting','Northing','Hubs','Bottom elevation SWEN17_RH2000']]
    flight_chirp = flight_chirp.rename(columns={'Hubs': 'Cross section coordinate (m)', 'Easting': "x."+flight_dict['Aux data']['xyEPSG'] + ' (m)', 'Northing': "y." + flight_dict['Aux data']['xyEPSG'] + ' (m)', 'Bottom elevation SWEN17_RH2000': 'z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'})
    flight_chirp_L2 = flight_chirp.copy(deep = True)
    flight_chirp_L2 = flight_chirp_L2.drop(columns = ['Cross section coordinate (m)'])
    flight_chirp_L2.to_csv(flight_dict['Aux data']['L2_output'],index = False)
    flight_chirp.to_csv(flight_dict['Aux data']['L3_output'],index = False)

def Hydrohexts_convert(hydrohexts,fstring):
    if fstring == 'micro':
        nofrag, frag = hydrohexts.split('.')
        nofrag_dt = datetime.strptime(nofrag, "%Y-%m-%d_%H:%M:%S")
        frag = int(frag.ljust(6, '0'))
        if frag >= 0:
            dt = nofrag_dt.replace(microsecond=frag)
        else:
            dt = np.nan
    if fstring == 'nano':
        nofrag, frag = hydrohexts.split('.')
        nofrag_dt = datetime.strptime(nofrag, "%Y-%m-%d_%H:%M:%S")
        frag = int(frag.ljust(9, '0'))
        if frag >= 0:
            dt = nofrag_dt.replace(microsecond=round(int(frag)/1000))
        else:
            dt = np.nan
    return dt

def readGekko_posfile(fname,datestr):
    file = open(fname)
    Lines = file.readlines()
    count = 0
    t = np.empty(0)
    traceno = np.empty(0)
    date = datetime.strptime(datestr, "%d-%m-%Y")
    for line in Lines:
        if '$GPGGA' in line:
            tracenonow = line.split(',')[0]
            tnow = line.split(',')[2]
            hours = float(tnow[0:2])
            mins = float(tnow[2:4])
            secs = float(tnow[4:])
            tnow = timedelta(hours=hours,minutes = mins, seconds=secs)
            t = np.append(t, tnow)
            traceno = np.append(traceno, tracenonow)
            count = count + 1
    t = date + t
    data=np.array([t,traceno])
    dftrace = pd.DataFrame(data.transpose(),columns=['UTC','Traceno'])
    return dftrace

def processGekkoflight_dict(flight_dict):
    xyEPSG = flight_dict  ['Aux data']['xyEPSG']
    zEPSG = flight_dict  ['Aux data']['zEPSG']
    cl = gpd.read_file(flight_dict['Aux data']['Filename reference line'])
    cl = cl.to_crs(crs=xyEPSG)
    dfref = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl['Distance']]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    eps = 81 #relative permittivity of water
    vwat = 3E8/eps**0.5
    for flight in flight_dict['flights']:
        if flight_dict ['flights'][flight]['posf_name'] != r'':
            dfgekko = readGekko_posfile(flight_dict ['flights'][flight]['posf_name'],flight_dict ['Aux data']['datestr'])
            dfpos = pd.read_csv(flight_dict['flights'][flight]['ppk_name'],skiprows = 9,delimiter=r"\s+")
            dfgekko = posinterp_tonly(dfgekko,dfpos,'%','UTC','latitude(deg)','longitude(deg)', 'height(m)', False)
            dfgekko = dfgekko.rename(columns={'Latitude interpolated': 'Latitude', 'Longitude interpolated': 'Longitude'})
            dfgekko = dfgekko.drop(columns = {'Altitude interpolated'})
            dfgekko['geometry'] = dfgekko.apply(lambda x: Point((float(x.Longitude), float(x.Latitude))), axis=1)
            dfgekko = gpd.GeoDataFrame(dfgekko, geometry='geometry', crs = 4326)
            dfgekko = dfgekko.to_crs(3006)
            dfgekko['Easting'] = dfgekko['geometry'].x
            dfgekko['Northing'] = dfgekko['geometry'].y
            dfgekko = hubdist(dfgekko,dfref,flight_dict['Aux data']['refline tol'])
        data,headers, sample_rate, ntrace, nsamples = readsegy(flight_dict ['flights'][flight]['segy_name'])
        # sample_rate = 0.75 # Done because some Gekko segy-files seem to have wrong sampling rate...
        ttorange = sample_rate*1E-9*vwat/2 #sampling rate in ns
        flight_dict ['flights'][flight]['manual bathymetry points']=dict()
        flight_dict ['flights'][flight]['automatic bathymetry points']=dict()
        sections = pd.read_excel(flight_dict ['flights'][flight]['sections'],index_col = 'Section')
        for s in sections.index:
            if flight_dict ['flights'][flight]['posf_name'] != r'':
                dfgekko['teststart']=(dfgekko['Traceno'].astype(int) - sections['Start Trace'][s])**2
                starti = dfgekko['teststart'].idxmin()
                dfgekko['testend']=(dfgekko['Traceno'].astype(int) - sections['End Trace'][s])**2
                endi = dfgekko['testend'].idxmin() +1
                indeces = range(starti,endi)
                spos_data = dfgekko.iloc[indeces]
                stime = dfgekko['UTC'].astype('datetime64[us]')
                feast = interpolate.interp1d(dfgekko['Traceno'].astype(int),dfgekko['Easting'])
                fnorth = interpolate.interp1d(dfgekko['Traceno'].astype(int),dfgekko['Northing'])
                #falt = interpolate.interp1d(spos_data['Hubs'],spos_data['Altitude SWEN17_RH2000'])
                fts = interpolate.interp1d(dfgekko['Traceno'].astype(int),stime)
                fdtrace = interpolate.interp1d(dfgekko['Traceno'].astype(int),dfgekko['Hubs'])
            else:
                fdtrace = interpolate.interp1d([sections['Start Trace'][s], sections['End Trace'][s]],[sections['Start line'][s], sections['End line'][s]])
                feast = interpolate.interp1d(dfref['Distance'],dfref['Easting'])
                fnorth = interpolate.interp1d(dfref['Distance'],dfref['Northing'])
                st = np.datetime64(datetime.strptime(str(sections['Start time'][s]),"%Y-%m-%d %H:%M:%S"))
                et = np.datetime64(datetime.strptime(str(sections['End time'][s]),"%Y-%m-%d %H:%M:%S"))
                fts = interpolate.interp1d([sections['Start Trace'][s], sections['End Trace'][s]] , [st, et])
            subdata = data[:,sections['Start Trace'][s]:sections['End Trace'][s]+1]
            ntrace = sections['End Trace'][s] - sections['Start Trace'][s] + 1
            #Background removal
            mdata = subdata.mean(1)
            mmdata = np.tile(mdata,(subdata.shape[1],1)).transpose()
            ndata = subdata-mmdata
            #surface identificatation
            otrace = np.abs(subdata).mean(1)
            surf = np.where(otrace==max(otrace))[0][0]*ttorange
            print(surf)
            # Linear gain
            traceindex = np.empty(subdata.shape[1])
            distindex = np.empty(subdata.shape[1])
            for i in range(subdata.shape[1]):
                traceindex[i] = sections['Start Trace'][s] + i
                distindex[i] = fdtrace(sections['Start Trace'][s] + i)
            rangeax = np.linspace(1,nsamples,nsamples)*ttorange
            gain = ((rangeax-flight_dict ['flights'][flight]['gain lt'])/(flight_dict ['flights'][flight]['gain ut']-flight_dict ['flights'][flight]['gain lt']))**flight_dict ['flights'][flight]['gain power']
            gain[rangeax<flight_dict ['flights'][flight]['gain lt']]=0
            gain[rangeax>flight_dict ['flights'][flight]['gain ut']]=1
            mgain = np.tile(gain,(subdata.shape[1],1)).transpose()
            gndata = ndata*mgain
            plt.figure()
            plt.pcolor(gndata,vmin=np.percentile(gndata,0.1),vmax=np.percentile(gndata,99.9))
            print('Please pick a rough lower bound on the bathymetry range:')
            points_prof = plt.ginput(-1,timeout = -1)
            points_prof = np.array(points_prof)
            points_prof[0,0]=0
            points_prof[-1,0]=gndata.shape[1]
            f = interpolate.interp1d(points_prof[:,0],points_prof[:,1])
            trax = np.linspace(0,gndata.shape[1]-1,gndata.shape[1])
            rax = np.linspace(0,gndata.shape[0]-1,gndata.shape[0])
            thresh_range = f(trax)
            tthresh_range= np.tile(thresh_range,(subdata.shape[0],1))
            thrx,thry = np.meshgrid(trax,rax)
            tgndata = gndata*(thry>tthresh_range)
            ttgndata = tgndata>np.max(tgndata)*flight_dict ['flights'][flight]['bw thresh']
            brange = trax*np.nan
            plt.figure()
            plt.pcolor(ttgndata)
            for t in trax:
                ind = t.astype('int')
                if np.where(ttgndata[:,ind])[0].size!=0:
                    brange[ind] = np.where(ttgndata[:,ind])[0][0]
            sdistindex = distindex[brange != np.nan]
            brange = brange[brange != np.nan]*ttorange
            autobpoints = flight_dict['Aux data']['WSE'] - brange + surf
            dfbathyauto = pd.DataFrame({'Cross section coordinate (m)': sdistindex, 'z.' + zEPSG + ' (m)': autobpoints})
            if flight_dict ['flights'][flight]['posf_name'] != r'':
                dfbathyauto["x."+xyEPSG + ' (m)'] = feast (trax + sections['Start Trace'][s])
                dfbathyauto["y." + xyEPSG + ' (m)'] = fnorth (trax + sections['Start Trace'][s])
                # dfbathyauto['Altitude'] = falt (dfbathyauto['Distance along reference line (m)'])
                dfbathyauto['Time stamp (UTC)'] = fts (trax + sections['Start Trace'][s])
            else:
                dfbathyauto["x."+xyEPSG + ' (m)'] = feast (dfbathyauto['Cross section coordinate (m)'])
                dfbathyauto["y." + xyEPSG + ' (m)'] = fnorth (dfbathyauto['Cross section coordinate (m)'])
                dfbathyauto['Time stamp (UTC)'] = fts (trax + sections['Start Trace'][s])
            flight_dict ['flights'][flight]['automatic bathymetry points'][s]= dfbathyauto
            if flight_dict['Aux data']['manual pick']:
                XXv,YYv = np.meshgrid(trax,rangeax)
                plt.figure()
                plt.pcolor(XXv,YYv,gndata,vmin=np.percentile(gndata,0.1),vmax=np.percentile(gndata,99.9))
                plt.xlabel('Traceno')
                plt.ylabel('GPR range, m')
                plt.title(flight_dict['Aux data']['XSid'] + ' flight ' + str(flight))
                print('Please pick bathymetry returns manually')
                points_prof = plt.ginput(-1,timeout = -1)
                points_prof = np.array(points_prof)
                points_prof[:,1]=points_prof[:,1]-surf
                wse = flight_dict['Aux data']['WSE']
                points_prof[:,1]=wse - points_prof[:,1]
                dfmanualpoints = pd.DataFrame({'Cross section coordinate (m)': fdtrace(sections['Start Trace'][s] + points_prof[:, 0]), 'Bed Elevation': points_prof[:, 1]})
                if flight_dict ['flights'][flight]['posf_name'] != r'':
                    dfmanualpoints["x."+xyEPSG + ' (m)'] = feast (points_prof[:, 0] + sections['Start Trace'][s])
                    dfmanualpoints["y." + xyEPSG + ' (m)'] = fnorth (points_prof[:, 0] + sections['Start Trace'][s])
#                   dfmanualpoints['Altitude'] = falt (dfmanualpoints['Distance along reference line (m)'])
                    dfmanualpoints['Time stamp (UTC)'] = fts (points_prof[:, 0] + sections['Start Trace'][s])
                else:
                    dfmanualpoints["x."+xyEPSG + ' (m)'] = feast (dfbathyauto['Distance along reference line (m)'])
                    dfmanualpoints["y." + xyEPSG + ' (m)'] = fnorth (dfbathyauto['Distance along reference line (m)'])
                    dfmanualpoints['Time stamp (UTC)'] = fts (points_prof[:, 0] + sections['Start Trace'][s])
                flight_dict ['flights'][flight]['manual bathymetry points'][s]= dfmanualpoints
    return flight_dict

def midsec(Ks,flight_dict):
    Q = 0
    g = 9.81
    npoints = flight_dict['npoints']
    lb = flight_dict['lb']
    dx = flight_dict['dx']
    wse = flight_dict['WSE']
    bcs = flight_dict['bcs']
    vcs = flight_dict['vcs']
    
    for i in range(0,npoints,1):
        xmid = lb + dx*i + dx/2
        #print(xmid)
        dl = wse-bcs(xmid-dx/2)
        if dl <0:
            dl = 0
        du = wse-bcs(xmid+dx/2)
        if du <0:
            du = 0
        md = (dl + du)/2
        Cl = Ks*dl**(1/6)
        Cu = Ks*du**(1/6)
        ml = Cl/g**0.5*(2*g**0.5 / (g**0.5 + Cl) + 0.3)
        mu = Cu/g**0.5*(2*g**0.5 / (g**0.5 + Cu) + 0.3)
        vl = vcs(xmid-dx/2)
        if vl <0:
            vl = 0
        vu = vcs(xmid+dx/2)
        if vu < 0:
            vu = 0
        vbulk = 0.5 * (ml/(ml+1)*vl + mu/(mu+1)*vu)
        dQ = vbulk/100*dx*md
        Q=Q+dQ
    return Q

def ManningE(Ks,flight_dict):
    npoints = flight_dict['npoints']
    lb = flight_dict['lb']
    rb = flight_dict['rb']
    dx = flight_dict['dx']
    wse = flight_dict['WSE']
    wss = flight_dict['WSS']
    bcs = flight_dict['bcs']
    
    rl = np.linspace(lb,rb,npoints)
    depth = wse-bcs(rl)
    depth[depth<0] = 0
    area = simpson(depth,dx = dx)
    WP = 0
    for i in range(0,npoints-1,1):
        WP = WP + ((rl[i]-rl[i+1])**2 + (bcs(rl[i])-bcs(rl[i+1]))**2)**0.5
    RH = area/WP
    Q = Ks*area*RH**(2/3)*(wss/1E5)**0.5
    return Q

def processDischarge(flight_dict):
    dx = flight_dict['dx']
    g = 9.81
    bdata = pd.read_csv(flight_dict['bath_L4_file'])
    plt.plot(bdata['Distance along reference line (m)'],bdata['z.' + flight_dict['zEPSG'] + ' (m)'],'k.')
    bdata = bdata.groupby(['Distance along reference line (m)'],as_index=False).mean()
    flight_dict['bcs'] = make_interp_spline(bdata['Distance along reference line (m)'], bdata['z.' + flight_dict['zEPSG'] + ' (m)'],k=1)
    bcs = flight_dict['bcs']
    helpfunc = lambda bx: (bcs(bx)-flight_dict['WSE'])**2
    res = minimize(helpfunc, flight_dict['rbguess'], method='SLSQP')
    rb = res.x[0]
    res = minimize(helpfunc, flight_dict['lbguess'], method='SLSQP')
    lb = res.x[0]
    flight_dict['rb'] = np.round(rb*10)/10
    rb = flight_dict['rb']
    flight_dict['lb'] = np.round(lb*10)/10
    lb = flight_dict['lb']
    flight_dict['npoints'] = int((rb-lb)/dx)+1
    npoints = flight_dict['npoints']
    rl = np.linspace(lb,rb,npoints)

    plt.figure()
    vdata = pd.read_csv(flight_dict['vel_L3_file'])
    vdata = vdata.groupby(['Distance along reference line (m)'],as_index=False).mean()
    plt.plot(vdata['Distance along reference line (m)'],vdata['Surface velocity (cm/s)'],'k.')
    vcs = make_interp_spline(vdata['Distance along reference line (m)'], vdata['Surface velocity (cm/s)'],k=1)
    flight_dict['vcs'] = vcs
    
    plt.figure()
    plt.plot(rl,bcs(rl))
    plt.plot(bdata['Distance along reference line (m)'],bdata['z.' + flight_dict['zEPSG'] + ' (m)'],'k.')
    plt.xlim([lb,rb])
    plt.figure()
    plt.plot(rl,vcs(rl))
    plt.plot(vdata['Distance along reference line (m)'],vdata['Surface velocity (cm/s)'],'k.')
    plt.xlim([lb,rb])
    print(ManningE(flight_dict['Ksguess'],flight_dict))
    print(midsec(flight_dict['Ksguess'],flight_dict))
    helpfunc = lambda Ks: (ManningE(Ks,flight_dict)-midsec(Ks,flight_dict))**2
    res = minimize(helpfunc, flight_dict['Ksguess'], method='SLSQP')
    flight_dict['Ksest']=res.x[0]
    flight_dict['Q_midsec'] = midsec(flight_dict['Ksest'],flight_dict)
    flight_dict['Q_Manning'] = ManningE(flight_dict['Ksest'],flight_dict)
    return flight_dict

def processRBelevL4 (flight_dict):
    xyEPSG = flight_dict  ['xyEPSG']
    zEPSG = flight_dict  ['zEPSG']
    cl = gpd.read_file(flight_dict['Filename reference line'])
    cl = cl.to_crs(crs=xyEPSG)
    dfref = pd.DataFrame(np.array([cl['geometry'].x,cl['geometry'].y,cl['Distance']]).transpose(), columns = ['Easting', 'Northing', 'Distance'])
    x=dfref.copy(deep=True)
    x = x[x['Distance']>flight_dict['lidlb']]
    x = x[x['Distance']<flight_dict['lidub']]
    lidarel = rinterp(x['Easting'].values,x['Northing'].values,flight_dict['Lidar DEM'],flight_dict['Lidar NaNvalue'])
    x['z.'+flight_dict  ['zEPSG'] + ' (m)'] = lidarel
    x = x[x['z.'+flight_dict  ['zEPSG'] + ' (m)']>flight_dict['WSE']+flight_dict['wsethresh']]
    x = x[np.logical_or(x['Distance']<flight_dict['lidarmask_l'], x['Distance']>flight_dict['lidarmask_r'])]
    flight_dict['Lidar el points'] = x
    bathpoints = pd.read_csv(flight_dict['bath_L3_file'])
    df1 = x[['Distance', 'z.'+flight_dict  ['zEPSG'] + ' (m)']]
    df1= df1.rename(columns={'Distance':'Distance along reference line (m)', 'z.'+flight_dict  ['zEPSG'] + ' (m)':'z.'+flight_dict  ['zEPSG'] + ' (m)'})
    df2 = bathpoints[['Distance along reference line (m)', 'River bottom elevation (m)']]
    df2= df2.rename(columns={'Distance along reference line (m)':'Distance along reference line (m)', 'River bottom elevation (m)':'z.'+flight_dict  ['zEPSG'] + ' (m)'})
    bdata = pd.concat([df1, df2], axis=0)
    bdata = bdata.groupby(['Distance along reference line (m)'],as_index=False).median()
    plt.plot(bdata['Distance along reference line (m)'],bdata['z.'+flight_dict  ['zEPSG'] + ' (m)'],'.')
    plt.plot(df1['Distance along reference line (m)'],df1['z.'+flight_dict  ['zEPSG'] + ' (m)'],'r.')
    # bdata2 = bdata.rolling(window=5).median()
    # bdata['z.'+flight_dict  ['zEPSG'] + ' (m)'] = bdata2['z.'+flight_dict  ['zEPSG'] + ' (m)']
    # bdata=bdata[~np.isnan(bdata['z.'+flight_dict  ['zEPSG'] + ' (m)'])]
    x=dfref.copy(deep=True)
    x = x[x['Distance']>flight_dict['lidlb']]
    x = x[x['Distance']<flight_dict['lidub']]
    bcs = UnivariateSpline(bdata['Distance along reference line (m)'], bdata['z.'+flight_dict  ['zEPSG'] + ' (m)'],s=flight_dict  ['spline_s1'])
    #plt.plot(x['Distance'],bcs(x['Distance']))
    bdata = bdata[np.abs(bdata['z.'+flight_dict  ['zEPSG'] + ' (m)'] - bcs(bdata['Distance along reference line (m)']))<flight_dict['othresh']]
    bcs = UnivariateSpline(bdata['Distance along reference line (m)'], bdata['z.'+flight_dict  ['zEPSG'] + ' (m)'],s=flight_dict  ['spline_s2'])
    plt.plot(x['Distance'],bcs(x['Distance']),'k')
    x['z.'+flight_dict  ['zEPSG'] + ' (m)'] = bcs(x['Distance'])
    x = x.rename(columns = {'Distance':'Distance along reference line (m)'})
    flight_dict['combined elevation'] = x
    flight_dict['combined elevation'].to_csv(flight_dict['L4 filename'])
    plt.xlabel('y in m')
    plt.ylabel('Elevation in m above reference')
    plt.show()
    
    return flight_dict   