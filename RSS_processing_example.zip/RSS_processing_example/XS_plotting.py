# -*- coding: utf-8 -*-
"""
Created on Sat Sep  2 20:08:42 2023

@author: pbau
"""
import numpy as np
from osgeo import gdal
from scipy import interpolate
from scipy.optimize import curve_fit
from datetime import datetime
import pandas as pd
import geopandas as gpd
import shapely
from shapely.geometry import Point
import segyio
from sklearn.linear_model import LinearRegression
from scipy.stats import norm
import matplotlib.pyplot as plt
import fiona
import os

from fiona.drvsupport import supported_drivers
supported_drivers['LIBKML'] = 'rw'


def plotRSSres(flight_dict):
    labels = [];
    if os.path.isfile(flight_dict ['Aux data']['in situ L3']):
        is_data = pd.read_csv(flight_dict ['Aux data']['in situ L3'])
        l1, = plt.plot(is_data['Cross section coordinate (m)'],is_data['Surface velocity (cm/s)'],'r*',label='OTT MFPro')
        labels.append(l1)
    XS_L3 = flight_dict['flights'][0]['waypoints'].head(0)
    for flight in flight_dict['flights']:
        XS_L3 = pd.concat([XS_L3,flight_dict['flights'][flight]['waypoints']])
    colcodes = ['k','b','g']
    fa = np.unique(XS_L3['Flight Altitude'])
    count = 0
    for faa in fa:
        plotpoints = XS_L3[XS_L3['Flight Altitude']==faa]
        #l2= plt.errorbar(plotpoints['Distance'],plotpoints['Velocity_fwd min'],yerr=(plotpoints['Velocity_fwd min_cov'].values)**0.5,linestyle='',marker='d',color=colcodes[count],label='Flight altitude ' + str(faa) +' m')
        l2,= plt.plot(plotpoints['Cross section coordinate (m)'],plotpoints['FW Velocity'],linestyle='',marker='d',color=colcodes[count],label='Flight altitude ' + str(faa) +' m')
        labels.append(l2)
        count = count+1
    plt.legend(handles = labels)
    plt.xlabel('Distance along cross section (m)')
    plt.ylabel('Surface velocity, cm/s')
    plt.title(flight_dict ['Aux data']['XSid'])
    
def plotZondres(flight_dict, xlim):
    fsize = 18
    plt.figure()
    WSE = flight_dict['Aux data']['WSE']
    if os.path.isfile(flight_dict ['Aux data']['in situ L3']):
        is_data = pd.read_csv(flight_dict ['Aux data']['in situ L3'])
    labels = [];
    for flight in flight_dict['flights']:
        XS_L3_auto = flight_dict['flights'][flight]['automatic bathymetry points'][1].head(0) 
        for s in flight_dict['flights'][flight]['automatic bathymetry points'].keys():
            XS_L3_auto = np.append(XS_L3_auto, flight_dict['flights'][flight]['automatic bathymetry points'][s], axis=0)
    
    if XS_L3_auto.size !=0:
        l3,= plt.plot(XS_L3_auto[:,0],XS_L3_auto[:,1],'r.', markersize = 3,label='Zond Aero automatic')
        labels.append(l3)  
    if os.path.isfile(flight_dict ['Aux data']['in situ L3']):
        l1, = plt.plot(is_data['XS coordinate (m)'],is_data['Elevation'],'k*',label='in situ')
        labels.append(l1)
    
    plt.plot(plt.gca().get_xlim(),[WSE,WSE],'b')
    plt.xlim(xlim)
    plt.xlabel('Distance along cross section, m',fontsize=fsize)
    plt.ylabel('River bottom elevation, m',fontsize=fsize)
    plt.title(flight_dict ['Aux data']['XSid'],fontsize=fsize)
    plt.tick_params(labelsize=fsize)
    plt.legend(handles = labels,fontsize=fsize-3)

    
def plotECT400res(flight_dict,xlim):
    WSE = flight_dict['Aux data']['WSE']
    if os.path.isfile(flight_dict ['Aux data']['is_file']):
        is_data = pd.read_csv(flight_dict['Aux data']['is_file'])
    L3data = pd.read_csv(flight_dict['Aux data']['L3_output'])
    if flight_dict ['Aux data']['FWF data']:
        L3data_fwf = pd.read_csv(flight_dict['Aux data']['L3_output full waveform'])
    plt.figure(figsize=(10,5))
    line1, = plt.plot(L3data['Cross section coordinate (m)'], L3data['z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'],'r.', label='L3 data',markersize=1)
    handles = [line1]
    if flight_dict ['Aux data']['FWF data']:
        line2, = plt.plot(L3data_fwf['Cross section coordinate (m)'], L3data_fwf['z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'],'g.', label='L3 data from full waveform',MarkerSize=1)
        handles = [line1, line2]
    if flight_dict ['Aux data']['FWF data']:
        line3, = plt.plot(is_data['Cross section coordinate (m)'],is_data['z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'],'k.', label='in situ')
        handles = handles.append(line3)
    plt.plot(plt.gca().get_xlim(),[WSE,WSE],'b')
    plt.xlim(xlim)
    plt.xlabel('Cross section coordinate (m)')
    plt.ylabel('z.' + flight_dict['Aux data']['zEPSG'] + ' (m)')
    plt.legend(handles=handles)
    plt.title(flight_dict ['Aux data']['XSid'])

def plotLX80res(flight_dict):
    for flight in flight_dict['flights']:    
        flight_lx80 = flight_dict ['flights'][flight]['Results']
        xyEPSG = flight_dict ['Aux data']['xyEPSG']
        zEPSG = flight_dict ['Aux data']['zEPSG']
        plt.figure()
        plt.plot(flight_lx80['Chainage (m)'],flight_lx80['WSE LX80 ' + zEPSG + ' slant (m)'],'k.',markersize = 0.3)
        #plt.plot(flight_lx80['Chainage (m)'],flight_lx80['WSE LX80 ' + zEPSG + ' nadir'],'r.', MarkerSize = 0.1)
        plt.ylim(flight_dict ['flights'][flight]['ylim'])
        plt.xlabel('chainage, m')
        plt.ylabel('WSE, m above ' + zEPSG)
        plt.title(flight_dict['flights'][flight]['n_flight_lx80'].split('\\')[-1] )
        plt.show()
        
def plotLX80res_all(flight_dict):
    plt.figure()
    for flight in flight_dict['flights']:    
        flight_lx80 = flight_dict ['flights'][flight]['Results']
        xyEPSG = flight_dict ['Aux data']['xyEPSG']
        zEPSG = flight_dict ['Aux data']['zEPSG']
        #plt.figure()
        plt.plot(flight_lx80['Chainage (m)'],flight_lx80['WSE LX80 ' + zEPSG + ' slant (m)'],'.',c=np.random.rand(3,),markersize = 0.5)
        #plt.plot(flight_lx80['Chainage (m)'],flight_lx80['WSE LX80 ' + zEPSG + ' nadir'],'r.', MarkerSize = 0.1)
    plt.ylim(flight_dict ['flights'][flight]['ylim'])
    # plt.xlim([109000,112000])
    # plt.ylim([185,195])
    plt.xlabel('chainage, m')
    plt.ylabel('WSE, m above ' + zEPSG)
    plt.title('All flights' )
    plt.show()
        
def plotDeeperChirp(flight_dict,xlim):
    WSE = flight_dict['Aux data']['WSE']
    is_data = pd.read_csv(flight_dict['Aux data']['is_file'])
    L3data = pd.read_csv(flight_dict['Aux data']['L3_output'])
    plt.figure(figsize=(10,5))
    line2, = plt.plot(L3data['Cross section coordinate (m)'], L3data['z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'],'r.', label='L3 data',MarkerSize=1)
    line1, = plt.plot(is_data['Cross section coordinate (m)'],is_data['z.' + flight_dict['Aux data']['zEPSG'] + ' (m)'],'k.', label='in situ')
    plt.plot(plt.gca().get_xlim(),[WSE,WSE],'b')
    plt.xlim(xlim)
    plt.xlabel('Cross section coordinate (m)')
    plt.ylabel('Elevation above SWEN17_RH 2000')
    plt.legend(handles=[line1, line2])
    plt.title(flight_dict ['Aux data']['XSid'])
    
def plot_L4(XS_dict):
    isf = pd.read_csv(XS_dict['is_L3_file'])
    l4f = pd.read_csv(XS_dict['L4 filename'])
    l1, = plt.plot(l4f['Distance along reference line (m)'],l4f['z.' + XS_dict['zEPSG'] + ' (m)'],'r-', label = 'L4 results')
    l2, = plt.plot(isf['Distance along reference line (m)'],isf['z.' + XS_dict['zEPSG'] + ' (m)'],'k.', label = 'in-situ')
    l3, = plt.plot(plt.gca().get_xlim(), [XS_dict['WSE'], XS_dict['WSE']],'b-',label = 'WSE')
    plt.title(XS_dict['XSid'])
    plt.legend(handles = [l1,l2,l3])
    plt.xlabel('Distance along reference line (m)')
    plt.ylabel('Elevation, m, SWEN17_RH2000')
    plt.show()
    